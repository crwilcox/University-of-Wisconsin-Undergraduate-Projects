/**
 * A class representing a single UFO object that can move, fire, and be hit.
 * 
 */
public class UFO {

	public static final int SIMPLE_SAUCER = 0;

	// the type of this UFO
	private int uFOType;
	// the current x position of this UFO
	private int xPosition;
	// the current y position of this UFO
	private int yPosition;

	/**
	 * Constructs an UFO object given its type and initial position
	 * 
	 * @param startX
	 *            The initial x coordinate
	 * @param startY
	 *            The initial y coordinate
	 * @param uFOType
	 *            An int representing the type of UFO this is.
	 */
	public UFO(int startX, int startY, int uFOType) {
		// write your code here
	}

	/**
	 * Get an int represented the type for this UFO
	 * 
	 * @return The int representing the type of this UFO
	 */
	public int getUFOType() {
		// write your code here
		return -1;
	}

	/**
	 * Get the current x coordinate of the center of this UFO.
	 * 
	 * @return The current x coordinate of the center of this UFO.
	 */
	public int getXPosition() {
		// write your code here
		return -1;
	}

	/**
	 * Get the current y coordinate of the center of this UFO.
	 * 
	 * @return The current y coordinate of the center of this UFO.
	 */
	public int getYPosition() {
		// write your code here
		return -1;
	}

	/**
	 * Updates the position of the UFO for the next time it is redrawn.
	 * 
	 * @param defender
	 *            The Defender object. May safely be ignored, but some UFO types
	 *            may use this information.
	 */
	public void takeOneStep(Defender defender) {
		// write your code here
	}

	/**
	 * Return true if this UFO fires this during this tick.
	 * 
	 * @param defender
	 *            The Defender object. May safely be ignored, but some UFO types
	 *            may use this information.
	 * @return Whether or not this UFO shoots on this tick
	 */
	public boolean shootsThisTurn(Defender defender) {
		// write your code here
		return false;
	}

	/**
	 * Return the bullet this UFO is about to fire.
	 * 
	 * @param defender
	 *            The Defender object. May safely be ignored, but some UFO types
	 *            may use this information.
	 * @return The bullet this UFO is about to fire.
	 */
	public Laser fireWeapon(Defender defender) {
		// write your code here
		return null;
	}

	/**
	 * Returns whether this UFO intersects this Laser
	 * 
	 * @param theLaser
	 * @return true if this UFO intersects this Laser
	 */
	public boolean hitByLaser(Laser theLaser) {
		// write your code here
		return false;
	}

	/**
	 * Returns true if this UFO has been destroyed.
	 * 
	 * @return true if the UFO has been destroyed.
	 */
	public boolean removeMeFromGame() {
		// write your code here
		return false;
	}

	/**
	 * Updates the Object to record that it has been hit by a Laser. This method
	 * is called every time the UFO is struck by a Laser.
	 */
	public void wasHit() {
		// write your code here
	}

}
